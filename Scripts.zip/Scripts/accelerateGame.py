def increase_difficulty(obstacles):

    for obs in obstacles:
        obs["speed"] += 0.001
