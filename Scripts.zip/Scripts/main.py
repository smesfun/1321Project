import pygame, sys, random
from Scripts import Player
from Scripts import endGame
from Scripts import obstacleBehavior
from Scripts import accelerateGame
from Scripts import gameSound

pygame.init()

resolution = (800, 600)
screen = pygame.display.set_mode(resolution)
pygame.display.set_caption("CSE Project")
clock = pygame.time.Clock()

jump_sound, game_over_sound = gameSound.load_sounds()

player = Player.Player((40, 50))
obstacles = obstacleBehavior.initialize_obstacles()

pygame.font.init()

game_font = pygame.font.SysFont('Arial', 30)

clouds = []
for i in range(6):
    cloud = pygame.Surface((80, 40))
    cloud.fill((220, 220, 220))
    cloud_x = i * 130 + 50
    cloud_y = random.randint(50, 150)
    clouds.append({"surface": cloud, "pos": (cloud_x, cloud_y)})


ground = pygame.Surface((800, 50))
ground.fill((100, 200, 100))

running = True
while running:
    screen.fill((255, 255, 255))

    game_surface = game_font.render('Click to jump over obstacles. Survive as long as possible', False, (0, 0, 0))
    screen.blit(game_surface, (0, 0))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                player.jump()
                jump_sound.play()

    player.update()
    obstacles = obstacleBehavior.update_obstacles(obstacles)
    accelerateGame.increase_difficulty(obstacles)

    if player.check_collision(obstacles):
        endGame.end_game(game_over_sound)
        running = False

    for cloud in clouds:
        screen.blit(cloud["surface"], cloud["pos"])

    screen.blit(ground, (0, resolution[1] - 150))

    player.draw(screen)
    obstacleBehavior.draw_obstacles(screen, obstacles)

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit()
